import{j as e,H as a}from"./index-B_PO8gLe.js";const p=({title:o,description:n,canonical:t,image:r="https://kevcodesdev.cl/og-image.jpg"})=>e.jsxs(a,{children:[e.jsx("title",{children:o}),e.jsx("meta",{name:"description",content:n}),e.jsx("meta",{name:"author",content:"Kevin Pardo Veas"}),e.jsx("meta",{name:"publisher",content:"Kevin Pardo"}),e.jsx("meta",{property:"og:site_name",content:"Kevin Pardo Portfolio"}),e.jsx("meta",{property:"og:locale",content:"es_CL"}),t&&e.jsx("link",{rel:"canonical",href:t}),e.jsx("meta",{property:"og:title",content:o}),e.jsx("meta",{property:"og:description",content:n}),e.jsx("meta",{property:"og:type",content:"website"}),e.jsx("meta",{name:"keywords",content:"Kevin Pardo, React Developer, Frontend Developer, MERN Stack, JavaScript Developer"}),e.jsx("meta",{property:"og:image",content:r}),t&&e.jsx("meta",{property:"og:url",content:t}),e.jsx("meta",{name:"twitter:card",content:"summary_large_image"}),e.jsx("meta",{name:"twitter:title",content:o}),e.jsx("meta",{name:"twitter:description",content:n}),e.jsx("meta",{name:"twitter:image",content:r}),e.jsx("meta",{name:"robots",content:"index, follow"}),e.jsx("script",{type:"application/ld+json",children:`
{
 "@context": "https://schema.org",
 "@type": "Person",
 "name": "Kevin Pardo",
 "url": "https://kevcodesdev.cl",
 "image": "https://kevcodesdev.cl/perfil.jpg",
 "jobTitle": "Frontend Developer",
 "description": "Frontend developer especializado en React, JavaScript y aplicaciones web modernas.",
 "sameAs": [
   "https://github.com/Krpardo27",
   "https://linkedin.com/in/kevinpardoveas"
 ]
}
`})]});export{p as S};
