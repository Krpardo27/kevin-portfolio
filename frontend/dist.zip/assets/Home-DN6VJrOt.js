import{j as e,L as r}from"./index-BdnEATVK.js";import{F as a,a as l}from"./index-3USJSs31.js";import{u as n}from"./useSEO-D_gvawkf.js";const o=()=>(n({title:"Kevin Pardo | Desarrollador Frontend React & MERN",description:"Portafolio de Kevin Pardo, desarrollador frontend especializado en React, Tailwind CSS y animaciones modernas.",canonical:"https://kevcodesdev.cl/"}),e.jsx("section",{className:"lg:mt-32 mt-8 px-4 py-5 flex flex-col items-center justify-center",children:e.jsxs("div",{className:"flex w-full flex-col lg:flex-row items-center gap-16",children:[e.jsxs("div",{className:"flex-1 w-full flex flex-col gap-8",children:[e.jsxs("header",{className:"relative",children:[e.jsx("h1",{className:`\r
        text-4xl md:text-6xl font-semibold text-white tracking-tight\r
        mb-3\r
      `,children:"Kevin Pardo Veas"}),e.jsx("div",{className:"h-[2px] w-24 bg-gradient-to-r from-blue-400 to-cyan-400 mb-4"}),e.jsx("p",{className:`\r
        text-lg md:text-xl\r
        font-medium\r
        bg-gradient-to-r from-blue-400 to-cyan-300\r
        bg-clip-text text-transparent\r
      `,children:"Desarrollador Frontend · React"})]}),e.jsx("div",{className:"flex flex-col gap-5 max-w-xl",children:e.jsx("p",{className:"text-gray-300 leading-relaxed text-base md:text-lg",children:"Desarrollo interfaces web funcionales, claras y orientadas al rendimiento, priorizando buenas prácticas y una experiencia de usuario sólida."})}),e.jsx("div",{className:"mt-6 flex flex-wrap gap-4",children:e.jsxs(r,{to:"/cv",className:`\r
    group\r
    inline-flex items-center gap-3\r
    px-7 py-3\r
    rounded-xl\r
    bg-gradient-to-r from-blue-500 to-cyan-500\r
    text-white font-medium\r
    shadow-lg shadow-blue-500/20\r
    hover:shadow-blue-500/40\r
    transition-all duration-300\r
    hover:scale-[1.04]\r
  `,children:[e.jsx(a,{className:`\r
      text-white/90\r
      transition-transform\r
      group-hover:rotate-6\r
    `}),"Resume",e.jsx(l,{className:`\r
      transition-transform\r
      group-hover:translate-x-1\r
    `})]})})]}),e.jsx("div",{className:"hidden lg:flex flex-1 items-center justify-center",children:e.jsxs("div",{className:"relative",children:[e.jsx("img",{src:"/perfil.jpg",alt:"Kevin Pardo Veas",loading:"lazy",className:`rounded-full w-[220px] h-[220px] lg:w-[320px] lg:h-[320px]\r
      object-cover border border-gray-700 shadow-xl`}),e.jsx("span",{className:"absolute inset-0 rounded-full border border-blue-500/30","aria-hidden":"true"})]})})]})}));export{o as default};
